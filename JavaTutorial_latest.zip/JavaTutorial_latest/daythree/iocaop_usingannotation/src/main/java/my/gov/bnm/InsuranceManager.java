package my.gov.bnm;

import my.gov.bnm.config.SpringModuleConfig;
import my.gov.bnm.models.Customer;
import my.gov.bnm.models.Insurance;
import my.gov.bnm.models.LifeInsurance;
import my.gov.bnm.models.MedicalInsurance;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class InsuranceManager {
	
	public static Customer getLifeInsuranceCustomer() {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.register(SpringModuleConfig.class);
		context.refresh();
		Customer customer = (Customer)context.getBean("lifeInsuranceCustomer");
		return customer;
	}
	
	
	public static Insurance getInsurance(char key) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.register(SpringModuleConfig.class);
		context.refresh();
		
		if (key == 'L') {
			
			Insurance lifeInsurance = (Insurance)context.getBean("lifeInsurance");
			return lifeInsurance;
		} else if (key == 'M') {
			Insurance medicalInsurance = (Insurance)context.getBean("medicalInsurance");
			return medicalInsurance;
		} else {
			return null;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Insurance medicalInsurance = getInsurance('M');
		medicalInsurance.setPeriod(10);
		medicalInsurance.setAmount(1455.55);
		System.out.println(medicalInsurance);
		
		// Assume every customer can have only one insurance
		Insurance lifeInsurance = getInsurance('L');
		
		System.out.println(lifeInsurance);
		
		
		Customer lifeInsuranceCustomer = getLifeInsuranceCustomer();
		System.out.println(lifeInsuranceCustomer);
		
		medicalInsurance.calculate();
		lifeInsurance.calculate();
	}

}
