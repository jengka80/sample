package my.gov.bnm.models;

public interface Insurance {
	
	public int getPeriod();

	public void setPeriod(int period);
	
	public double getAmount();
	
	public void setAmount(double amount);
	
	public void calculate();

}
