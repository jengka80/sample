package my.gov.bnm.aop;

public class Logging {
	
	public void beforeAdvice() {
		System.out.println("Before...");
	}

	public void afterAdvice() {
		System.out.println("After...");
	}
}
