package my.gov.bnm.models;

import org.springframework.stereotype.Component;

@Component("customer")
public class Customer {
	
	private String name;
	private Insurance insurance;

	public Customer() {
		super();
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Insurance getInsurance() {
		return insurance;
	}

	public void setInsurance(Insurance insurance) {
		this.insurance = insurance;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", insurance=" + insurance + "]";
	}

}
