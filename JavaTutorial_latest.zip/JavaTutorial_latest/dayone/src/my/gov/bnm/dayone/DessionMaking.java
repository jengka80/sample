package my.gov.bnm.dayone;

public class DessionMaking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int givenNumber = 0;
		if (givenNumber > 0) {
			System.out.println("Positive Number");
		} else {
			if (givenNumber == 0) {
				System.out.println("Zero");
			} else {
				System.out.println("Negative Number");
			}
		}
		if (givenNumber > 0) {
			System.out.println("Positive Number");
		} else if (givenNumber == 0) {
			System.out.println("Zero");
		} else {
			System.out.println("Negative Number");
		}
		int x = 10;
		int y = 3;
		char op = 'A';
		int result = (op == 'A') ? x + y : (op == 'S') ? x - y : (op == 'M') ? x * y : x / y;
		System.out.println(result);
		char obtainedGrade = 'D';
		switch(obtainedGrade) {
			case 'A':
				System.out.println("First Grade");
				break;
			case 'B':
				System.out.println("Second Grade");
				break;
			case 'C':
				System.out.println("Third Grade");
				break;
			case 'F':
				System.out.println("Fail");
				break;
			default:
				System.out.println("Unknown Grade");
				break;
		}
	}

}
