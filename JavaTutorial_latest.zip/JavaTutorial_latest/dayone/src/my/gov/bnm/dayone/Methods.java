package my.gov.bnm.dayone;

public class Methods {
	
	// this is how methods are declared

	// public is an access modifier 
	// (compulsory if you don't put anything then it will take default access modifier)
	
	// static is a modifier
	// (not compulsory however this case it is compulsory because this method is going to be
	// called from a static method
	// Rule: Static method can call only Static method
	// In this case main is a static method, if we are going to call sayHello method from the
	// main method, since mail method is already static sayHello method also must be static
	
	// void is the return data type 
	// (since we are not going to return anything we mention it as void)
	public static void sayHello() {
		System.out.println("Hello");
	}
	
	// let us create a method which take 3 parameters and return a value
	// return type is float, so you must have return keyword followed by a variable of type float
	// this method is taking parameters such as principle, period and rate
	public static float simpleInterest(float principle, float period, float rate) {
		float interest = (principle * period * rate) / 100;
		return interest;
	}
	
	public static int sum(int[] numbers) {
		int total = 0;
		for (int number:numbers) {
			total = total + number;
		}
		return total;
	}
	
	// REST parameters
	public static int total(int... numbers) {
		int total = 0;
		for (int number:numbers) {
			total = total + number;
		}
		return total;
	}
	
	// Java do not have optional parameters feature
	// Rather it has overloading feature
	// It means, you can have more than one method with same name inside a class
	// However the methods differentiated by the number of parameters
	// Overloading is having more than one method with same name inside the class
	public static void sayHi() {
		System.out.println("No Name");
	}
	
	public static void sayHi(String name) {
		System.out.println(name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// let us call or invoke the sayHello method
		sayHello();
		sayHello();
		// since the method is taking few parameters we must pass the arguments
		float interest = simpleInterest(1000, 1, 6);
		System.out.println("Interest Amount: " + interest);
		// sometime we may not know how many arguments we are going to pass
		int mynumbers[] = {10, 20, 30, 40, 50, 60};
		System.out.println(sum(mynumbers));
		int othernumbers[] = {10, 20, 30, 40};
		System.out.println(sum(othernumbers));
		// In the latest Java you no need to pass the values as an array
		// During the function call, you can pass them as individual items 
		// and JRE will put all the individual items inside an array and 
		// pass the array to the method
		System.out.println(total(10, 20, 30, 40, 50));
		sayHi();
		sayHi("David");
		
		// so far we know whatever variables created inside the method are local to the method
		// this is called functional scope (method scope) variable
		// However in java they also have block scope feature
		{
			int a = 10;
			int x = 15;
			{
				int b = 15;
				// variable created in the parent block can be accessed from child block
				System.out.println(a);
				System.out.println(b);
				
				// Cannot create a variable with same name which already exists in the parent block
				// int x = 25;
		
				// if we modify the global variable inside the block
				a = 15; // the global variable gets modified
			}
			// variable created inside the child block cannot be accessed from parent block
			// System.out.println(b);
			System.out.println(a);
			System.out.println(x);
		}
	}

}
