package my.gov.bnm.dayone;

public class Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int multiplier = 1;
		int multiplicant = 5;
		while (multiplier <= 12) {
			System.out.println(multiplier + " x " + multiplicant + " = " + multiplier * multiplicant);
			multiplier++;
		}

		multiplicant = 6;
		for (multiplier = 1; multiplier <= 12; multiplier++) {
			System.out.println(multiplier + " x " + multiplicant + " = " + multiplier * multiplicant);
		}
		
		multiplier = 0;
		multiplicant = 7;
		// if the multiplier is also 7 do not print the statement
		// even though the while loop is until 12 exit when multiplier is 10
		while (multiplier <= 12) {
			multiplier++;
			if (multiplier == 7) continue; // when the condition satisfy jump to while
			if (multiplier > 10) break; // when the condition satisfy exit the while loop
			System.out.println(multiplier + " x " + multiplicant + " = " + multiplier * multiplicant);
		}
		
		// to iterate through the array they do have for each loop
		int[] mynumbers = {10, 20, 30, 40, 50};
		// mynumber is a temporary variable which is holding the current value during the
		// iteration process
		for (int mynumber:mynumbers) {
			System.out.println(mynumber);
		}

		int [][] ourNumbers = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
		for (int[] mynumber:ourNumbers) {
			for (int currentnumber: mynumber) {
				System.out.println(currentnumber);
			}
		}
	}

}
