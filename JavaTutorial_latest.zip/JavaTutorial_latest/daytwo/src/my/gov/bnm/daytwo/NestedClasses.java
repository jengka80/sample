package my.gov.bnm.daytwo;

// A single java program can have multiple classes
// but only one class can be public
class OuterClass {
	// Class can have inner classes
	class InnerClass {
		public void sayHello() {
			System.out.println("Hello...");
		}
	}
	// Inner classes can have access modifiers
	private class PrivateInnerClass {
		
	}
	PrivateInnerClass privateInnerClass = new PrivateInnerClass();
	// Inner classes can also be static class
	static class StaticInnerClass {
		public void sayHello() {
			System.out.println("Hello");
		}
	}
}

public class NestedClasses {
	
	class InnerClassInsidePublicClass {
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// We are creating the instance of OuterClass
		OuterClass outerClass = new OuterClass();
		// We are creating the instance of InnerClass
		OuterClass.InnerClass innerClass = outerClass.new InnerClass();
		// OuterClass.InnerClass innerClass = (new OuterClass()).new InnerClass();
		innerClass.sayHello();
		// We are creating the reference to StaticInnerClass
		OuterClass.StaticInnerClass staticInnerClass = new OuterClass.StaticInnerClass();
		staticInnerClass.sayHello();
	}

}
