package my.gov.bnm.daytwo.models;

public class EditMenu extends Menu {

	public EditMenu(String name) {
		super(name);
	}

	@Override
	public void click() {
		System.out.println("Edit");
	}

}
