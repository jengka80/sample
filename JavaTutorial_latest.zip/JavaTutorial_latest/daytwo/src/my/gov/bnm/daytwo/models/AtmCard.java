package my.gov.bnm.daytwo.models;

public interface AtmCard {
	
	public float withdraw(float amount);

}
