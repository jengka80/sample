package my.gov.bnm.daytwo.models;

// is-a relationship
public class Graduate extends Student {
	
	private int membershipNumber;

	public Graduate(int id, String code, String name, 
			double openingBalance, int membershipNumber) {
		super(id, code, name, openingBalance);
		this.membershipNumber = membershipNumber;
	}

	public int getMembershipNumber() {
		return membershipNumber;
	}

	public void setMembershipNumber(int membershipNumber) {
		this.membershipNumber = membershipNumber;
	}

	@Override
	public String toString() {
		String result = super.toString() + "\n";
		result += "Graduate [membershipNumber=" + membershipNumber + "]";
		return result;
	}

}
