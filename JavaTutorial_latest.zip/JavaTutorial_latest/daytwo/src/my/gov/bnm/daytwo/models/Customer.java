package my.gov.bnm.daytwo.models;

// Syntax for class creation
// access_modifier class ClassName
// Customer is a class (blue print)
public class Customer {
	
	// let us create properties for Customer class
	// properties are nothing but variables declared inside the class but outside the method
	// In java usually the properties are declared with private access modifier
	// private means the properties cannot be accessed from outside of the class
	public int id;
	public String code;
	public String name;	
	public double openingBalance;
	
	// lets say we want to find out how many customer object has been created
	public static int count; // class variable

	// properties are usually initialized inside the constructor
	// constructors are special methods, which gets called every time 
	// somebody create an object of this class
	// we do not call constructors they get called automatically
	// the method name is same as class name and they do not return anything including void
	public Customer() {
		System.out.println("Inside Constructor");
		// you can use constructor to initialize the properties
		this.id = 0;
		this.code = "";
		this.name = "";
		this.openingBalance = 0;
		count = count + 1; // to access the static variable no need to use this keyword
	}

	// constructor overloading
	public Customer(int id, String code, String name, double openingBalance) {
		System.out.println("Inside Constructor");
		// you can use constructor to initialize the properties
		this.id = id;
		this.code = code;
		this.name = name;
		this.openingBalance = openingBalance;
		count = count + 1;
	}
	
	// Instance method (not class method)
	// To call Instance method first you must create object
	// and then object.print()
	public void print() {
		System.out.println("Id: " + this.id);
		System.out.println("Code: " + this.code);
		System.out.println("Name: " + this.name);
		System.out.println("Opening Balance: " + this.openingBalance);
	}

}
