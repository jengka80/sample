package my.gov.bnm.daytwo;

import my.gov.bnm.daytwo.models.Graduate;
import my.gov.bnm.daytwo.models.Passport;
import my.gov.bnm.daytwo.models.Student;
import my.gov.bnm.daytwo.services.StudentService;

public class StudentManager {
	
	// Following is a factory method
	// which takes some parameter based on the parameter value sometimes
	// it returns Student object sometimes it returns Graduate object
	// Child object can be assigned to a variable of type Parent Class
	public static Student getStudent(char key) {
		if (key == 'S') {
			return new Student(0, "", "", 0);
		} else if (key == 'G') {
			return new Graduate(0, "", "", 0, 0);
		} else {
			return null;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student = new Student(1, "C001", "Khairi", 4825.25);
		try {
			student.setId(-1);
		} catch(Exception ex) {
			System.out.println(ex.toString());
		}
		// by default when you pass an object to the
		// System.out.println this will call the toString method
		// which is inside the object
		System.out.println(student);
		Graduate graduate = new Graduate(2, "C002", "Chan", 2545.75, 97409);
		Passport passport = new Passport("A484843933", "China");
		graduate.setPassport(passport);
		System.out.println(graduate);

		// Similarly when we call the factory methods it may return different different objects
		// better to create a variable of type parent class and assign the return value
		// this concept is called Polymorphism
		Student newStudent = getStudent('S');
		newStudent = getStudent('G');
		
		// since the constructor inside the StudentService is private
		// we cannot instantiate the StudentService class
		// we are calling the static method getStudentService which will return the single 
		// instance of StudentService class
		StudentService studentService = StudentService.getStudentService();
		studentService.findAll();
	}

}
