package my.gov.bnm.daytwo.models;

public class BankCard implements CreditCard, DebitCard, AtmCard{
	
	private String accountNumber;
	private float openingBalance;

	public BankCard(String accountNumber, float openingBalance) {
		super();
		this.accountNumber = accountNumber;
		this.openingBalance = openingBalance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public float getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(float openingBalance) {
		this.openingBalance = openingBalance;
	}

	@Override
	public float withdraw(float amount) {
		// TODO Auto-generated method stub
		this.openingBalance = this.openingBalance - amount;
		return this.openingBalance;
	}

	@Override
	public float doPayBills(String accountNumber, float amount) {
		// TODO Auto-generated method stub
		System.out.println("Account Number: " + accountNumber);
		this.openingBalance = this.openingBalance - amount;
		return this.openingBalance;
	}

	@Override
	public void doShopping(String accoutNumber, float amount) {
		// TODO Auto-generated method stub
		System.out.println("Account Number: " + accountNumber);
		this.openingBalance = this.openingBalance - amount;		
	}

	@Override
	public String toString() {
		return "BankCard [accountNumber=" + accountNumber + 
				", openingBalance=" + openingBalance + "]";
	}

}
