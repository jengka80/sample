package my.gov.bnm.daytwo.models;

public class Passport {
	
	private String passportNumber;
	private String country;
	
	public Passport(String passportNumber, String country) {
		super();
		this.passportNumber = passportNumber;
		this.country = country;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Passport [passportNumber=" + passportNumber + ", country=" + country + "]";
	}

}
