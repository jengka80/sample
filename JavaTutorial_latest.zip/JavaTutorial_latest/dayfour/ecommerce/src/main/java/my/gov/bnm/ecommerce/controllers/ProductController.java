package my.gov.bnm.ecommerce.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import my.gov.bnm.ecommerce.models.Product;
import my.gov.bnm.ecommerce.services.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/api/products")
	public List<Product> doListProducts(){
		List<Product> products = (List<Product>)this.productService.findAll();
		return products;
	}
	
	@GetMapping("/api/products/{id}")
	public Product doGetProduct(@PathVariable("id") Optional<Long> id) {
		Product product = null;
		if(id.isPresent()) product = this.productService.findById(id.get());
		return product;
	}
	
	@PostMapping("/api/products")
	public void doSaveProduct(@RequestBody Product product) {
		this.productService.save(product);
		
	}
	
	@PutMapping("/api/products/{id}")
	public void doUpdateProduct(@PathVariable("id") Optional<Long> id, @RequestBody Product product) {
		this.productService.save(product);
	}
	
	@DeleteMapping("/api/products/{id}")
	public void doDeleteProduct(@PathVariable("id") Optional<Long> id, @RequestBody Product product) {
		if(id.isPresent())
		this.productService.delete(id.get());
	}
	
	@GetMapping("api/products/count")
	public int getCount() {
		List<Product> products = this.productService.findAll();
		return products.size();
	}
}
