package my.gov.bnm.ecommerce.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import my.gov.bnm.ecommerce.models.Product;

public interface ProductsRepository extends JpaRepository <Product, Long> {

}
