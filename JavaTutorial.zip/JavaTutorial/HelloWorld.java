// Every Java Program must have one public class and the class Name must be same as file name
// This class may have main method (not compulsory)
public class HelloWorld {

	public static void main(String args[]) {
		System.out.println("Hello World !!!");
	}

}