// Package help us to organize our code
package my.gov.bnm.dayone;

// Class - Blue print
public class Variables {

	// Function (in other language) inside the class
	// This is called as method in Java
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Variables declared inside the method are called local variables
		// Syntax for creating variables => data_type variable = literal (value)
		// numbers without decimal
		byte serialNumber = 127; // 8 (1111 1111) bit number (range -128 to 127)
		short quantity = 32767; // 16 bit number (range -32,768 to 32,767)
		int amount = 2147483647; // 32 bit number (range -2147483648 to 2147483647)
		// In Java the literals without decimals are treated as Integer by default
		long totalAmount = 9223372036854775807L; // 64 bit number (range -9223372036854775808 to 9223372036854775807)
		
		// numbers with decimal
		// In Java the literals with decimals are treated as Double by default
		// Even though you assign 5.5 (5.5 itself treated as Double (64 bit) Which you are trying to assign it to a 
		// variable of size 32 bit
		float perAmount = 5.5F; // 32 bit number
		double amountToBePaid = 5.5; // 64 bit number
		
		// + is used as arithmetic operator and also used as 
		// string concatenation operator
		System.out.println("Serial Number: " + serialNumber);
		System.out.println("Quantity: " + quantity);
		System.out.println("Ämount: " + amount);
		System.out.println("Total Ämount: " + totalAmount);
		System.out.println("Per Ämount: " + perAmount);
		System.out.println("Ämount to be Paid: " + amountToBePaid);
		
		// Whatever we discuss above is all primitive data type
		// The latest version they also introduce reference data type
		// They are also called wrapper data type
		Byte mySerialNumber = 127; // mySerialNumber is an object created from a class Byte
		// You can assign Null to mySerialNumber
		mySerialNumber = null;
		// However performance wise serialNumber is better than mySerialNumber
		// Since mySerialNumber is an object it has some overhead (performance and memory usage)
		// In java they introduce this because they want to claim Java is also 100% OOP
		// Byte class can be used to convert string to byte
		// parse methods will convert string to byte / string to short / string to integer
		Byte mynewnumber = Byte.parseByte("10");
		Short myQuantity = 32767;
		Integer myAmount = 2147483647;
		Long myTotalAmount = 9223372036854775807L;
		Float myPerAmount = 5.5F;
		Double myAmountToBePaid = 5.5;
		
		
		// Boolean and Character
		boolean isCitizen = true; // 1 bit only
		char alphabet = 'A'; // 16 bit to store unicode character (Characters are enclosed with single quote '')
		
		// Type Casting convert from one to another data type
		// byte -> short -> int -> long -> float -> double (widening casting)
		// double -> float -> long -> int -> short -> byte (narrowing casting) (you may loose data here)
		int x = 10;
		long y = x;
		x = (int)y; // during narrowing casting must use int explicitly
		double z = 655.55;
		x = (int)z;
		System.out.println(x);
		
		// So far we discuss how to assign single value to a single variable
		// Now let us discuss how to assign multiple values to single variable
		// Variables are created and assigned with multiple values
		// [] is used for variable declaration {} is used for values
		int[] quantities = { 10, 20, 30, 40, 50 };
		System.out.println(quantities[0]);
		// length is a property of array class
		// quantities (object) is instance of the array class
		System.out.println(quantities.length);
		// how to get the last number
		System.out.println(quantities[quantities.length - 1]);
		
		// What will happen if we try to access an index which is not there
		// System.out.println(quantities[5]); // this cause runtime exception 
		// and program gets terminated abnormally
		System.out.println("Thank you"); // this will never get printed
		// Runtime error in Java is handled by try catch exception block
		
		// operators
		System.out.println(10 + 10);
		System.out.println(20 - 10);		
		System.out.println(20 * 3);
		System.out.println(20 / 3); // when you divide integer / integer you get integer (quotient)
		System.out.println(20 % 3); // this will give you the remainder
		System.out.println(20 / 3.0); // either one of the value must be with decimal (float or double)
		
		// unary operator
		x = 10;
		System.out.println(x++); // print x first and then only increment
		System.out.println(x); 
		System.out.println(++x); // increment x first and then only print
		System.out.println(x);
		// similarly we also have --
		
		
		// assignment operator
		x = 10; // = is assignment operator
		x += 1; // (x = x + 1)
		System.out.println(x);
		x += 10; // (x = x + 10)
		System.out.println(x);
		// we also have -=, *=, /=, %=
		
		// comparison operators
		x = 10;
		y = 10;
		z = 20;
		System.out.println(x == y);
		System.out.println(x != z);
		System.out.println(x < z);
		System.out.println(z > x);
		System.out.println(x <= y);
		System.out.println(y >= x);
		
		// logical operators (and, or, not)
		// both conditions must be true => true
		System.out.println((x == y) && (x < z));
		// either one of the condition has to be true => true
		System.out.println((x == y) || (x > z));
		
		isCitizen = true;
		System.out.println(!isCitizen);
		
	}

}
