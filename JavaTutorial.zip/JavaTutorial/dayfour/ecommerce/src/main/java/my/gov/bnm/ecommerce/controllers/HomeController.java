package my.gov.bnm.ecommerce.controllers;

import java.util.List;
import java.util.Optional;

//import org.hibernate.query.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import my.gov.bnm.ecommerce.models.Product;
import my.gov.bnm.ecommerce.services.ProductService;

@Controller
public class HomeController {
	
	@Autowired
	private ProductService productService;
	
	
	
	@RequestMapping("/")
	public String index(Model model, @RequestParam("pagenumber") Optional<Integer> pagenumber) {
		int pageNumber = 0;
		if(pagenumber.isPresent()) pageNumber = pagenumber.get();
		PageRequest pageRequest = PageRequest.of(pageNumber, 3);
		Page<Product> products = this.productService.findAll(pageRequest);
		model.addAttribute("products",products);
		model.addAttribute("folder", "products");
		model.addAttribute("page","index");
		return "index";
	}
	
	@RequestMapping("/products/new")
	public String doNew(Model model) {
		Product product = new Product();
		model.addAttribute("product", product);
		model.addAttribute("folder", "products");
		model.addAttribute("page","new");
		return "index";
	}
	
	@RequestMapping(path="/products/edit/{id}")
	public String doEdit(Model model, @PathVariable("id") Optional<Long> id) {
		
		if(id.isPresent()) {			
		
			Product product = this.productService.findById(id.get());
			model.addAttribute("product", product);
			model.addAttribute("folder", "products");
			model.addAttribute("page","new");
			return "index";
		}else {
			return "redirect:/";
		}
	}
	
	@RequestMapping(path="/products/delete/{id}")
	public String doDelete(Model model, @PathVariable("id") Optional<Long> id) {
		
		if(id.isPresent()) {			
		
			this.productService.delete(id.get());
			
			return "redirect:/";
		}else {
			return "redirect:/";
		}
	}
	
	@RequestMapping(path="/products/save", method=RequestMethod.POST)
	public String saveProduct(Product product) {
		this.productService.save(product);
		return "redirect:/";
	}
	
	@RequestMapping(path="/products/search", method=RequestMethod.POST)
	public String doSearch(Model model,@RequestParam String keyword) {
		List<Product> products = this.productService.doSearchByProductName(keyword);
		model.addAttribute("products", products);
		model.addAttribute("folder", "products");
		model.addAttribute("page","index");
		return "index";
	}

}
