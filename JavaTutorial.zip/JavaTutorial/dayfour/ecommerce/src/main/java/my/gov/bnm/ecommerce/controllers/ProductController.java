package my.gov.bnm.ecommerce.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import my.gov.bnm.ecommerce.models.Product;
import my.gov.bnm.ecommerce.services.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping("/api/products")
	public List<Product> doListProducts(){
		List<Product> products = (List<Product>)this.productService.findAll();
		return products;
	}
	
	@RequestMapping("/api/products/{id}")
	public Product doGetProduct(@PathVariable("id") Optional<Long> id) {
		Product product = null;
		if(id.isPresent()) product = this.productService.findById(id.get());
		return product;
	}
}
