package my.gov.bnm.ecommerce.services;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import my.gov.bnm.ecommerce.models.Product;
import my.gov.bnm.ecommerce.repositories.ProductRepository;
import my.gov.bnm.ecommerce.repositories.ProductsRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ProductsRepository productsRepository;
	
	
	public List<Product> findAll(){
		return (List<Product>)this.productRepository.findAll();
		
	}
	
	public Page<Product> findAll(Pageable pageable){		
		return this.productsRepository.findAll(pageable);
	}
	
	public void save(Product product) {
		this.productRepository.save(product);
	}
	
	public Product findById(long id) {
		Optional<Product> product = this.productRepository.findById(id);
		if(product.isPresent()) {
			return product.get();
		}else {
			return null;
		}
	}
	
	public void delete(long id) {
		this.productRepository.deleteById(id);
	}
	
	public List<Product> doSearchByProductName(String keyword){
		return this.productRepository.findByNameContaining(keyword);
	}
}
