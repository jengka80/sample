package my.gov.bnm.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class Logging {
	
	@Pointcut("execution(* my.gov.bnm.models.*.calculate(..))")
	public void pointcutCalculate() {}
	
	@Before("pointcutCalculate()")
	public void beforeAdvice() {
		System.out.println("Before...");
	}
	
	@After("pointcutCalculate()")
	public void afterAdvice() {
		System.out.println("After...");
	}
}
