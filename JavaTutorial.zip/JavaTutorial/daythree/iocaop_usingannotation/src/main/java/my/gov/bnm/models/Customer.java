package my.gov.bnm.models;

// Whenever your class (Customer) depends on another class (Insurance)
// You should never create instance of the other class (Insurance) in this class (Customer)
// using new keyword
public class Customer {
	
	private String name;
	private Insurance insurance;

	public Customer() {
		super();
		// insurance = new LifeInsurance(); // you should never do this in this class
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Insurance getInsurance() {
		return insurance;
	}

	public void setInsurance(Insurance insurance) {
		this.insurance = insurance;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", insurance=" + insurance + "]";
	}

}
