package my.gov.bnm.models;

public class MedicalInsurance implements Insurance {

	private int period;
	private double amount;

	public MedicalInsurance() {
		super();
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}
	
	public double getAmount() {
		return amount;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "MedicalInsurance [period=" + period + ", amount=" + amount + "]";
	}
	
	@Override
	public void calculate() {
		// TODO Auto-generated method stub
		double totalAmountToBePaid = this.amount * this.period;
		System.out.println("Total amount to be paid: " + totalAmountToBePaid);
	}

}
