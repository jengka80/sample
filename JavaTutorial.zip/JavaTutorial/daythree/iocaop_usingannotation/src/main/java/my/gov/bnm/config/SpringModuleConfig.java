package my.gov.bnm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;

import my.gov.bnm.aop.Logging;
import my.gov.bnm.models.Customer;
import my.gov.bnm.models.Insurance;
import my.gov.bnm.models.LifeInsurance;
import my.gov.bnm.models.MedicalInsurance;

@PropertySource("classpath:data.properties")
@Configuration
@EnableAspectJAutoProxy()

public class SpringModuleConfig {
	@Value("${lifeInsurance.period}")
	private int lifeInsurancePeriod;
	
	@Value("${lifeInsurance.amount}")
	private double lifeInsuranceAmount;
	
	@Value("${lifeInsurance.customerName}")
	private String customerName;
	
	@Bean(name="medicalInsurance")
	public Insurance getMedicalInsurance() {
		MedicalInsurance medicalInsurance = new MedicalInsurance();
		return medicalInsurance;
	}
	
	@Bean(name="lifeInsurance")
	public Insurance getLifeInsurance() {
		LifeInsurance lifeInsurance = new LifeInsurance(lifeInsurancePeriod,lifeInsuranceAmount);
		return lifeInsurance;
	}
	
	@Bean(name="lifeInsuranceCustomer")
	public Customer getLifeInsuranceCustomer() {
		Customer customer = new Customer();
		customer.setName(this.customerName);
		customer.setInsurance(this.getLifeInsurance());
		return customer;
	}
	
	@Bean(name="logging")
	public Logging getLogging() {
		return new Logging();
	}

}
