package my.gov.bnm;

import my.gov.bnm.models.Customer;
import my.gov.bnm.models.Insurance;
import my.gov.bnm.models.LifeInsurance;
import my.gov.bnm.models.MedicalInsurance;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class InsuranceManager {
	
	public static Customer getLifeInsuranceCustomer() {
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Module.xml");
		Customer customer = (Customer)context.getBean("lifeInsuranceCustomer");
		return customer;
	}
	
	// Object creations must be in a central location
	// We should not use new keyword in multiple places
	// By doing it this way if anybody change the constructor
	// it will affect only this method the rest all will always be OK
	public static Insurance getInsurance(char key) {
		// Over here ApplicationContext is an Interface
		// ClassPathXmlApplicationContext is an Implementation Class
		// The constructor of this class takes an xml file as argument
		// that contains all the bean definitions
		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Module.xml");
		if (key == 'L') {
			// Spring Framework fundamentally was introduced to take care
			// of this following line
			// When ever we need instance/object of LifeInsurance we are going
			// to ask Spring to give us the Object
			// this feature of Spring is called Inversion of Control (IOC)
			// return new LifeInsurance(0, 0);
			Insurance lifeInsurance = (Insurance)context.getBean("lifeInsurance");
			return lifeInsurance;
		} else if (key == 'M') {
			Insurance medicalInsurance = (Insurance)context.getBean("medicalInsurance");
			return medicalInsurance;
		} else {
			return null;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Insurance medicalInsurance = getInsurance('M');
		medicalInsurance.setPeriod(10);
		medicalInsurance.setAmount(1455.55);
		System.out.println(medicalInsurance);
		
		// Assume every customer can have only one insurance
		Insurance lifeInsurance = getInsurance('L');
		// lifeInsurance.setPeriod(10);
		// lifeInsurance.setAmount(1455.55);
		System.out.println(lifeInsurance);
		
		Customer customer = new Customer();
		customer.setName("Khairi Bin Abu Bakar");
		customer.setInsurance(lifeInsurance);
		System.out.println(customer);
		
		Customer lifeInsuranceCustomer = getLifeInsuranceCustomer();
		System.out.println(lifeInsuranceCustomer);
		
		medicalInsurance.calculate();
		lifeInsurance.calculate();
	}

}
