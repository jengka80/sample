package my.gov.bnm.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import my.gov.bnm.models.Customer;
import my.gov.bnm.services.CustomerService;

@Component("customerController")
//@Scope("prototype")
@Scope("singleton")
public class CustomerController {
	private CustomerService customerService;
	
	@Autowired
	public CustomerController(CustomerService customerService) {
		super();
		this.customerService = customerService;
	}
	
	public Customer getCustomer() {
		return this.customerService.getCustomer();
	}
	

}
