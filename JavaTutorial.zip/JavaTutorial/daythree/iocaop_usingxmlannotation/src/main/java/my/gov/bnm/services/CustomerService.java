package my.gov.bnm.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import my.gov.bnm.models.Customer;

@Component("customerService")
public class CustomerService {
	
	@Autowired
	private Customer customer;
	public Customer getCustomer() {
		//Customer customer = new Customer();
		this.customer.setName("Peter Parker");
		return customer;
	}

}
