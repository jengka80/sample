package my.gov.bnm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import my.gov.bnm.config.SpringModuleConfig;
import my.gov.bnm.controllers.CustomerController;
import my.gov.bnm.models.Customer;

public class MainApplication {
	
	public static void main (String[] args) {
//		ApplicationContext context = new ClassPathXmlApplicationContext("Spring-Module.xml");
//		CustomerController customerController = context.getBean("customerController", CustomerController.class);
//		Customer customer = customerController.getCustomer();
//		System.out.println(customer);
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.register(SpringModuleConfig.class);
		context.refresh();
		CustomerController customerController = context.getBean("customerController", CustomerController.class);
		Customer customer = customerController.getCustomer();
		System.out.println(customer);
		
		CustomerController customerControllerOne = context.getBean("customerController", CustomerController.class);
		CustomerController customerControllerTwo = context.getBean("customerController", CustomerController.class);
		System.out.println(customerControllerOne == customerControllerTwo);
	}
	}


