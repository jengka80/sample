package my.gov.bnm;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import my.gov.bnm.models.Employee;

public class EmployeeManager {
	
	private SessionFactory sessionFactory;
	private Session session;
	
	public void getSession() {
		this.session = this.sessionFactory.getCurrentSession();
	}
	
	public List<Employee> findAll(){
		List<Employee> employees = null;
		try {
			this.getSession();
			this.session.beginTransaction();
			employees = this.session.createQuery("from Employee", Employee.class)
					.getResultList();
			this.session.getTransaction().commit();
		}catch (Exception ex) {
			ex.printStackTrace();
			this.sessionFactory.close();
		}
		return employees;
	}
	
	public Employee findById(int id) {
		Employee employee = null;
		try {
			getSession();
			this.session.beginTransaction();
			employee = this.session.get(Employee.class, id);
			this.session.getTransaction().commit();
		}catch (Exception ex) {
			ex.printStackTrace();
			this.sessionFactory.close();
		}
		return employee;
	}
	public void save(Employee employee) {
		try {
			getSession();
			this.session.beginTransaction();
			this.session.persist(employee);
			this.session.getTransaction().commit();
		}catch (Exception ex){
			ex.printStackTrace();
			this.sessionFactory.close();
		}
	}
	
	public void updateEmailUsingHQL(int id, String email) {
		try {
			getSession();
			this.session.beginTransaction();
			String hql = "UPDATE Employee e SET e.email ='"+ email +"' where e.id =" + id;
			
			this.session.createQuery(hql).executeUpdate();
			this.session.getTransaction().commit();
		} catch (Exception ex) {
			
		}
	}
	
	public void doList() {
		List<Employee> employees = this.findAll();
		for (Employee employee:employees) {
			System.out.println(employee);
		}
	}
	
	public Employee doFindById(int id) {
		Employee employee = this.findById(id);
		return employee;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeManager employeeManager = new EmployeeManager();
		employeeManager.sessionFactory = new Configuration()
				.configure("hibernate.cfg.xml")
				.addAnnotatedClass(Employee.class)
				.buildSessionFactory();
		
		Employee employee = new Employee("John", "john@gmail.com", "password");
		employeeManager.save(employee);
		employeeManager.doList();
	}

}
