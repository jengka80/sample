package my.gov.bnm.daytwo;

public class StringTutorial {

	public static void main(String[] args) {
		// There are 2 ways you can create a string literal
		String message01 = "Hello World";
		String message02 = "Hello World";
		String message03 = new String("Hello World");
		
		// Functional wise they are exactly same
		// However, they way they are stored is totally different
		System.out.println(message01);
		System.out.println(message02);
		System.out.println(message03);
		System.out.println(message01.toUpperCase());
		System.out.println(message02.toUpperCase());
		System.out.println(message03.toUpperCase());
		
		// Creating string object using second method takes more space
		// When we use == (comparison operator) It checks for the address not the content
		if (message01 == message02) {
			System.out.println("Strings are Equal");
		} else {
			System.out.println("Strings are not Equal");
		}
		if (message01 == message03) {
			System.out.println("Strings are Equal");
		} else {
			System.out.println("Strings are not Equal");
		}
		// You must always use equals method when you compare strings in Java
		if (message01.equals(message03)) {
			System.out.println("Strings are Equal");
		} else {
			System.out.println("Strings are not Equal");
		}
		
	}

}
