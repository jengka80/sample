package my.gov.bnm.daytwo.services;

import my.gov.bnm.daytwo.models.Student;

// This is a Singleton Class
// this particular class is not going to have any properties
// this is state less class
public class StudentService {
	
	// Second step is create a property that can hold the instance of StudentService Class
	// Make this property static so that only one instance will be created
	private static StudentService studentService;

	// First we must stop people creating multiple instances
	// you can make the constructor as private
	private StudentService() {
	}
	
	// Third step create a public getter method for studentService property
	public static StudentService getStudentService() {
		if (studentService == null) studentService = new StudentService();
		return studentService;
	}
	
	public Student[] findAll() {
		Student[] students = new Student[5];
		return students;
	}
}
