package my.gov.bnm.daytwo;

import my.gov.bnm.daytwo.models.EditMenu;
import my.gov.bnm.daytwo.models.FileMenu;
import my.gov.bnm.daytwo.models.Menu;

public class MenuManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu menuOne = new FileMenu("File");
		Menu menuTwo = new EditMenu("Edit");
		Menu menuThree = new Menu("Source") {
			@Override
			public void click() {
				System.out.println("Source");
			}
		};
		Menu menuFour = new Menu("Refactor") {
			@Override
			public void click() {
				System.out.println("Refactor");
			}
		};
		menuOne.click();
		menuTwo.click();
		menuThree.click();
		menuFour.click();
	}

}
