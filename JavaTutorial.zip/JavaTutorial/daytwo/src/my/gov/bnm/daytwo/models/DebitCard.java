package my.gov.bnm.daytwo.models;

public interface DebitCard {
	
	public float doPayBills(String accountNumber, float amount);

}
