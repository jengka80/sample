package my.gov.bnm.daytwo;

// Let us import the Customer class
import my.gov.bnm.daytwo.models.Customer;

public class CustomerManager {

	// JRE calls the main method
	// We use public, because the main method must be accessible to JRE
	// JRE do not want to create an object or your class
	// JRE do not want to do this CustomerManager customerManager = new CustomerManager()
	// If instance method then customerManager.main()
	// To execute our method JRE just want to do this (java CustomerManager)
	// CustomerManager.main()
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Let us create instance of Customer Class (Customer object)
		// We are creating the object using the new keyword
		Customer david = new Customer();
		Customer peter = new Customer(-1, "CUST001", "Peter", 2500.75);

		peter.id = -1;
		// accessing the instance variables
		System.out.println(peter.id);
		System.out.println(peter.code);
		System.out.println(peter.name);
		System.out.println(peter.openingBalance);
		peter.print();
		
		// accessing the static variable
		System.out.println(peter.count);
		System.out.println(Customer.count);
	}

}