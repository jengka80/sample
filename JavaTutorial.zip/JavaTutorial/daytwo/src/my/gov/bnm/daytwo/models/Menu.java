package my.gov.bnm.daytwo.models;

public abstract class Menu {

	private String name;

	public Menu(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	// If we implement the click method here then every single time it 
	// will print Hello
	// We must do an abstraction (no implementation here will be done some where else), 
	// however we cannot go for interface since
	// we already have methods such as getter, setter, toString
	// public void click() {
		// System.out.println("Hello");
	// }
	// We can use another modifier abstract, when we have 1 abstract method in a class
	// the entire class becomes abstract class
	// Abstract class also cannot be instantiated (cannot create object)
	// You must extend this class and create another class with the implementation
	// from that class you can create an object
	public abstract void click();

	@Override
	public String toString() {
		return "Menu [name=" + name + "]";
	}

}
