package my.gov.bnm.daytwo;

import java.util.ArrayList;
import java.util.HashMap;

import my.gov.bnm.daytwo.models.Student;

public class ArrayListTutorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// You must tell him the data type of our values which we going to keep inside the list
		ArrayList<String> fruits = new ArrayList<String>();
		fruits.add("Apple");
		fruits.add("Orange");
		fruits.add("Mango");
		System.out.println(fruits.get(0));
		for (String fruit:fruits) {
			System.out.println(fruit);
		}
		
		fruits.set(1, "Durian");
		for (String fruit:fruits) {
			System.out.println(fruit);
		}

		fruits.remove(1);
		for (String fruit:fruits) {
			System.out.println(fruit);
		}
		
		ArrayList<Student> students = new ArrayList<Student>();
		students.add(new Student(1, "S001", "Khairi", 550.25));
		students.add(new Student(2, "S002", "Peter", 350.25));
		for (Student student:students) {
			System.out.println(student);
		}
		
		HashMap<String, String> capitals = new HashMap<String, String>();
		capitals.put("Malaysia", "Kuala Lumpur");
		capitals.put("England", "London");
		System.out.println(capitals.get("England"));
	}

}
