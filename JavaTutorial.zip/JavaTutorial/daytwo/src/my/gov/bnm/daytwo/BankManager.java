package my.gov.bnm.daytwo;

import my.gov.bnm.daytwo.models.BankCard;
import my.gov.bnm.daytwo.models.CreditCard;

public class BankManager {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankCard bankCard = new BankCard("1234-5678-9012", 1585.25F);
		// Interface cannot be instantiated (cannot create objects from Interface)
		// Objects can be created only from Class
		// Object of child class (BankCard) can be assigned to variable of type parent class (CreditCard)
		CreditCard creditCard = new BankCard("1234-5678-9012", 1585.25F);
		// Even though bank card object is assigned to the crediCard variable
		// now using the creditCard variable we can access the method that belongs to 
		// CrediCard interface only
		
		// Can we try to create a creditCard Object using anonymous class
		// We can also instantiate interfaces using Anonymous Class
		CreditCard cCard = new CreditCard() {

			@Override
			public void doShopping(String accoutNumber, float amount) {
				// TODO Auto-generated method stub
			}
			
		};
	}

}
