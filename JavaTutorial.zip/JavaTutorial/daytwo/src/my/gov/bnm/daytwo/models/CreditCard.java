package my.gov.bnm.daytwo.models;

public interface CreditCard {

	public void doShopping(String accoutNumber, float amount);

}
