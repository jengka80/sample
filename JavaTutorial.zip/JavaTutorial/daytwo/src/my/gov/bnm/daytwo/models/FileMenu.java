package my.gov.bnm.daytwo.models;

// since Menu class is an abstract when we extend we must
// implement the abstract methods
public class FileMenu extends Menu {

	public FileMenu(String name) {
		super(name);
	}

	@Override
	public void click() {
		// TODO Auto-generated method stub
		System.out.println("File");
	}

}
